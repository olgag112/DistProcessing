import socket
import pickle

class Client:
    def __init__(self, server_ip, port=5555):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.client.connect((server_ip, port))
        print(f"Connected to server {server_ip}")
        self.client.setblocking(False)

    def send(self, data):
        try:
            self.client.sendall(pickle.dumps(data))
        except Exception as e:
            print("Send error:", e)

    def receive(self):
        try:
            data = self.client.recv(4096)
            if data:
                return pickle.loads(data)
        except BlockingIOError:
            return None
        except Exception as e:
            print("Receive error:", e)
            return None

    def close(self):
        self.client.close()
