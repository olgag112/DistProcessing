# server.py
import socket
import pickle

class Server:
    def __init__(self, host='', port=5555):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((host, port))
        self.server.listen(1)
        print(f"[SERVER] Waiting for connection on port {port}...")
        self.conn, self.addr = self.server.accept()
        print(f"[SERVER] Connected to {self.addr}")

    def send(self, data):
        try:
            self.conn.send(pickle.dumps(data))
        except Exception as e:
            print("[SERVER] Send failed:", e)

    def receive(self):
        try:
            data = self.conn.recv(4096)
            self.conn.settimeout(2.0)  # Timeout in seconds
            return pickle.loads(data)
        except socket.timeout:
            return None
        except Exception as e:
            print("[SERVER] Receive failed:", e)
            return None
